const express = require('express');
const indexModel=require('../models/indexModel')
const router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/about', function(req, res, next) {
  res.render('about');
});

router.get('/contact', function(req, res, next) {
  res.render('contact');
});


router.get('/service', function(req, res, next) {
  res.render('service');
});


router.get('/register', function(req, res, next) {
  res.render('register',{'output':''});
});
router.post('/register', function(req, res, next) {
  indexModel.register(req.body).then((result)=>{
  	res.render('register',{'output':'Register successfully....'});
  }).catch((err)=>{
  	console.log(err)
  })
});


router.get('/login', function(req, res, next) {
  res.render('login',{'output':''});
});
router.post('/login', function(req, res, next) {
  indexModel.login(req.body).then((result)=>{
  	if(result.length>0)
  	{
  		if(result[0].role=="admin")
  			res.redirect('/admin')
  		if(result[0].role=="user")
  			res.redirect('/user')	
  	}
  	else
  		res.render('login',{'output':'Invalid User or Verify your account from inbox......'});
  }).catch((err)=>{
  	console.log(err)
  })
});


module.exports = router;
