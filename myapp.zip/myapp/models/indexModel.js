const pool=require('./connection')

function indexModel()
{
  this.register=(userDetails)=>{
  	return new Promise((resolve,reject)=>{
  		pool.getConnection((err,con)=>{
  			var sqlQuery="insert into register values(NULL,?,?,?,?,?,?,?,'user',?,0)"
  			var sqlData=[userDetails.name,userDetails.email,userDetails.password,userDetails.mobile,userDetails.address,userDetails.city,userDetails.gender,Date()]
  			con.query(sqlQuery,sqlData,(err,result)=>{
  				con.release()
  				err ? reject(err) : resolve(result);
  				
  			})
  		})
  	})
  }
  
  this.login=(userDetails)=>{
	  return new Promise((resolve,reject)=>{
	  	pool.getConnection((err,con)=>{
	  		var sqlQuery="select * from register where email=? and password=? and status=1"
	  		var sqlData=[userDetails.email,userDetails.password]
	  		con.query(sqlQuery,sqlData,(err,result)=>{
	  			con.release()
	  			err ? reject(err) : resolve(result); 
	  		})
	  	})
	  })
  }
  
}

module.exports=new indexModel()



